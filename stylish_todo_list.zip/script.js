
function addTask() {
    const taskInput = document.getElementById("taskInput");
    const taskList = document.getElementById("taskList");

    if (taskInput.value.trim() !== "") {
        const li = document.createElement("li");
        li.textContent = taskInput.value;
        li.onclick = () => {
            if (confirm("Mark this task as done and remove?")) {
                li.remove();
            }
        };
        taskList.appendChild(li);
        taskInput.value = "";
    }
}
