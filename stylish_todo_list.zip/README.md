
# Stylish To-Do List App

A polished and responsive to-do list using HTML, CSS, and JavaScript. Perfect for learning DOM manipulation, CSS styling, and interactive design.

## Features
- Add new tasks
- Click to remove with confirmation
- Stylish UI with responsive design

## How to Use
1. Open `index.html` in your browser.
2. Type a task and click "Add Task".
3. Click any task to mark as done (and remove).

## Author
Sankalp Tidke
