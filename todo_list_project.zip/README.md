
# Simple To-Do List App

A basic HTML/CSS/JavaScript to-do list where you can add and remove tasks.  
Great for beginners practicing DOM manipulation and UI styling.

## Features
- Add tasks
- Click on a task to remove it

## How to Use
1. Open `index.html` in your browser.
2. Type a task and click "Add".
3. Click any task to remove it.

## Preview

![preview](screenshot.png)

## Author
Sankalp Tidke
